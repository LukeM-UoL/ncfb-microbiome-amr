## =========================================================
## R: Diagnose + analyse link between AMR genes & diversity
## Files used:
##   - merged_genus_resfinder_tpONLY.csv
##   - ResFinder_output_all_dedup.csv
## Outputs:
##   - linked_tp_checked.csv
##   - diagnostics.txt
##   - spearman_kw_results.txt
##   - fig_scatter_shannon.png
##   - fig_box_shannon_quartiles.png
##   - (optional) model_summary.txt
## =========================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(ggplot2)
  library(stringr)
})

merged_path <- "merged_genus_resfinder_tpONLY.csv"
res_path    <- "ResFinder_output_all_dedup.csv"

# ---------- helpers ----------
pick_col <- function(nms, candidates, fallback_first = TRUE) {
  for (c in candidates) {
    hit <- which(tolower(nms) == tolower(c))
    if (length(hit)) return(nms[hit[1]])
  }
  if (fallback_first) return(nms[1])
  NA_character_
}
extract_tp <- function(x) {
  x <- tolower(trimws(as.character(x)))
  m <- regexpr("\\b([tp]\\d+)\\b", x, perl = TRUE)
  ifelse(m > 0, tolower(regmatches(x, m)), NA_character_)
}
n_distinct_chr <- function(x) dplyr::n_distinct(na.omit(as.character(x)))
n_num <- function(x) sum(is.finite(x))

# ---------- read ----------
stopifnot(file.exists(merged_path), file.exists(res_path))
merged <- read.csv(merged_path, check.names = FALSE)
res    <- read.csv(res_path,    check.names = FALSE)

# ---------- build tp_id on both ----------
m_id_col <- pick_col(names(merged), c("tp_id","sample_id","file","id","name"))
r_id_col <- pick_col(names(res),    c("tp_id","isolate_id","sample_id","isolate","sample","id","name"))

merged <- merged %>%
  mutate(tp_id = if ("tp_id" %in% names(.)) tolower(as.character(tp_id)) else extract_tp(.data[[m_id_col]]))

res <- res %>%
  mutate(tp_id = if ("tp_id" %in% names(.)) tolower(as.character(tp_id)) else extract_tp(.data[[r_id_col]]))

# ---------- summarise ResFinder per tp_id ----------
gene_col  <- pick_col(names(res), c("resistance_gene","gene","arg"))
pheno_col <- pick_col(names(res), c("phenotype","class","drug_class"), fallback_first = FALSE)

res_by_tp <- res %>%
  group_by(tp_id) %>%
  summarise(
    ARG_hits               = n(),
    replicates_n_res       = n_distinct_chr(.data[[r_id_col]]),
    ARG_richness_res       = n_distinct_chr(.data[[gene_col]]),
    Phenotype_richness_res = if (!is.na(pheno_col)) n_distinct_chr(.data[[pheno_col]]) else NA_integer_,
    .groups = "drop"
  )

# ---------- join ----------
linked <- merged %>% left_join(res_by_tp, by = "tp_id")

# ---------- make sure SHANNON is numeric ----------
# try common spellings/cases; then parse numbers robustly
shan_col <- pick_col(names(linked), c("shannon","Shannon","shannon_diversity"))
linked$shannon_num <- readr::parse_number(as.character(linked[[shan_col]]))

# choose outcome
if ("ARG_richness_res" %in% names(linked)) {
  linked$ARG_richness_use <- suppressWarnings(as.numeric(linked$ARG_richness_res))
} else if ("ARG_richness" %in% names(linked)) {
  linked$ARG_richness_use <- suppressWarnings(as.numeric(linked$ARG_richness))
} else {
  linked$ARG_richness_use <- NA_real_
}

# ---------- diagnostics ----------
diag_lines <- c(
  sprintf("merged rows: %d | unique tp_id (merged): %d | non-NA tp_id (merged): %d",
          nrow(merged), dplyr::n_distinct(na.omit(merged$tp_id)), sum(!is.na(merged$tp_id))),
  sprintf("res rows: %d | unique tp_id (res): %d | non-NA tp_id (res): %d",
          nrow(res), dplyr::n_distinct(na.omit(res$tp_id)), sum(!is.na(res$tp_id))),
  sprintf("intersection tp_id: %d",
          length(intersect(na.omit(unique(merged$tp_id)), na.omit(unique(res$tp_id))))),
  sprintf("non-missing shannon_num: %d / %d", n_num(linked$shannon_num), nrow(linked)),
  sprintf("non-missing ARG_richness_use: %d / %d", n_num(linked$ARG_richness_use), nrow(linked))
)

# show a few examples if things look empty
if (n_num(linked$shannon_num) == 0) {
  diag_lines <- c(diag_lines, "WARNING: shannon_num has 0 finite values. Check the column name/values.")
}
if (n_num(linked$ARG_richness_use) == 0) {
  head_missing <- linked %>% select(tp_id, starts_with("ARG_richness")) %>% head(10)
  capture <- paste(capture.output(print(head_missing)), collapse = "\n")
  diag_lines <- c(diag_lines, "WARNING: ARG_richness_use has 0 finite values. Here are the first rows:", capture)
}

writeLines(diag_lines, "diagnostics.txt")
write_csv(linked, "linked_tp_checked.csv")

# ---------- bail early if no analysable rows ----------
df <- linked %>%
  transmute(
    tp_id,
    shannon = shannon_num,
    ARG_richness = ARG_richness_use,
    total_counts = if ("total_counts" %in% names(linked)) suppressWarnings(as.numeric(total_counts)) else NA_real_,
    replicates_n = if ("replicates_n_res" %in% names(linked)) suppressWarnings(as.numeric(replicates_n_res))
    else if ("replicates_n" %in% names(linked)) suppressWarnings(as.numeric(replicates_n))
    else NA_real_
  ) %>%
  filter(is.finite(shannon), is.finite(ARG_richness))

if (nrow(df) == 0) {
  cat("No rows to analyse. See 'diagnostics.txt' for counts and column names.\n")
  quit(save = "no")
}

# ---------- stats ----------
# Spearman
spear <- suppressWarnings(cor.test(df$shannon, df$ARG_richness, method = "spearman", exact = FALSE))
lines <- c(
  "=== Spearman correlation ===",
  sprintf("rho = %.3f, p = %.4g, n = %d", unname(spear$estimate), spear$p.value, nrow(df))
)

# Quartiles + Kruskal–Wallis
df$shannon_q <- cut(df$shannon,
                    breaks = quantile(df$shannon, probs = seq(0,1,0.25), na.rm = TRUE),
                    include.lowest = TRUE,
                    labels = c("Q1 (low)","Q2","Q3","Q4 (high)"))
kw <- kruskal.test(ARG_richness ~ shannon_q, data = df)
lines <- c(lines, "",
           "=== Kruskal–Wallis across Shannon quartiles ===",
           sprintf("H = %.3f, p = %.4g", as.numeric(kw$statistic), kw$p.value))

# Simple count model (optional)
if (all(is.finite(df$total_counts)) && all(is.finite(df$replicates_n))) {
  fit <- glm(ARG_richness ~ shannon + log1p(total_counts) + replicates_n,
             family = poisson(), data = df)
  disp <- sum(residuals(fit, type = "pearson")^2) / df.residual(fit)
  if (is.finite(disp) && disp > 1.5) {
    fit <- glm(ARG_richness ~ shannon + log1p(total_counts) + replicates_n,
               family = quasipoisson(), data = df)
  }
  co <- summary(fit)$coefficients
  est <- co["shannon","Estimate"]; se <- co["shannon","Std. Error"]; p <- co["shannon","Pr(>|z|)"]
  irr <- exp(est); ci <- exp(c(est - 1.96*se, est + 1.96*se))
  lines <- c(lines, "",
             "=== Count model (Poisson/Quasi) ===",
             sprintf("IRR_shannon = %.3f (95%% CI %.3f–%.3f), p = %.4g | dispersion %.2f",
                     irr, ci[1], ci[2], p, ifelse(is.finite(disp), disp, NA_real_)))
} else {
  lines <- c(lines, "", "Count model skipped (missing total_counts or replicates_n).")
}

write_lines(lines, "spearman_kw_results.txt")

# ---------- figures ----------
ggplot(df, aes(shannon, ARG_richness)) +
  geom_point(alpha = .6) +
  geom_smooth(method = "loess", se = TRUE) +
  labs(x = "Shannon diversity (genus)", y = "P. aeruginosa ARG richness",
       title = "ARG richness vs microbiome diversity") +
  theme_classic()
ggsave("fig_scatter_shannon.png", width = 6, height = 4, dpi = 300)

ggplot(df, aes(shannon_q, ARG_richness)) +
  geom_boxplot(outlier.shape = NA) +
  geom_jitter(width = .12, alpha = .35, size = 1) +
  labs(x = "Shannon quartile", y = "P. aeruginosa ARG richness",
       title = "ARG richness across Shannon quartiles") +
  theme_classic()
ggsave("fig_box_shannon_quartiles.png", width = 6, height = 4, dpi = 300)

cat("Done. See 'diagnostics.txt', 'linked_tp_checked.csv', 'spearman_kw_results.txt', and the two PNGs.\n")
