library(dplyr)
library(tidyr)

df <- read.csv("AMR_01.csv")

# Grouping by unique resistance genes
df_unique <- df %>%
  group_by(isolate_id, resistance_gene) %>%
  slice_max(order_by = coverage, n = 1, with_ties = FALSE) %>%  # Keeps one unique row with the highest coverage,
  ungroup()                                                     # Cleans up after grouping

# Categorize into 100% coverage and 0-99%
df_unique <- df_unique %>%
  mutate(coverage_cat = ifelse(coverage == 100, "100", "0-99"))


# Group and count
summary_df <- df_unique %>%
  group_by(isolate_id, coverage_cat) %>%                    # count prep by isolate_id & coverage  
  summarise(gene_count = n(), .groups = 'drop') %>%         # summarizes unique genes per isolate ID per category
  pivot_wider(                                              # Reshaping, coverage is grouped in two categories
    names_from = coverage_cat,
    values_from = gene_count,                               # Fill in 0 if not in either category
    values_fill = 0
  )


write.csv(summary_df, "gene_coverage_summary.csv", row.names = FALSE)


# Tabulated summary final*

gene_summary <- df_unique %>%
  mutate(gene_coverage = paste0(resistance_gene, "(", coverage, "%)")) %>%
  group_by(isolate_id) %>%
  summarise(
    amr_gene_count = n_distinct(resistance_gene),
    gene_types_with_coverage = paste(unique(gene_coverage), collapse = ", "),
    .groups = "drop"
  )

write.csv(gene_summary, "fin_amr_gene_summary_per_isolate.csv", row.names = FALSE)

# AMR gene count per isolate

library(ggplot2)

ggplot(gene_summary, aes(x = reorder(isolate_id, -amr_gene_count), y = amr_gene_count)) +
  geom_bar(stat = "identity", fill = "steelblue") +
  labs(title = "AMR Gene Count per Isolate",
       x = "Isolate ID",
       y = "AMR Gene Count") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 90, hjust = 1))


# 10 Most common AMR genes

top_genes <- df_unique %>%
  count(resistance_gene, sort = TRUE) %>%
  slice_max(n, n = 10)

ggplot(top_genes, aes(x = reorder(resistance_gene, n), y = n)) +
  geom_bar(stat = "identity", fill = "darkorange") +
  coord_flip() +
  labs(title = "Top 10 AMR Genes Across All Isolates",
       x = "AMR Gene",
       y = "Count") +
  theme_minimal()



